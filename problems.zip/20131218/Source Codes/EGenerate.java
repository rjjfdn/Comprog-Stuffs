import java.util.*;
import java.io.*;

public class EGenerate {

    public static void main(String[] args) throws Exception {
    	PrintWriter printer = new PrintWriter(new FileWriter("e.in"));
    	printer.println(5);
    	for(int i=0; i<5; i++) {
    		int n = (int)(Math.random()*100);
    		printer.println(n);
    		for(int j=0; j<n; j++) {
    			int x2 = (int)(Math.random()*10000);
    			int y2 = (int)(Math.random()*10000);
    			int x1 = (int)(Math.random()*x2);
    			int y1 = (int)(Math.random()*y2);
    			x1 -= 5000;
    			y1 -= 5000;
    			x2 -= 5000;
    			y2 -= 5000;
    			printer.println(x1 + " " + y1 + " " + x2 + " " + y2);
    		}
    	}
    	printer.close();
    }
}
