import java.util.*;
import java.io.*;

public class A {
	
	static int[][] dp;
	static int xx, yy;
	
	public static int backtrack(int x, int y) {
		if(x == xx && y == yy)
			return 1;
		if(dp[x][y] != 0)
			return dp[x][y];
		int ret = 0;
		if(x+1 <= xx)
			ret = (ret + backtrack(x+1, y)) % 1000007;
		if(y+1 <= yy)
			ret = (ret + backtrack(x, y+1)) % 1000007;
		if(x+1 <= xx && y+1 <= yy)
			ret = (ret + backtrack(x+1, y+1)) % 1000007;
		dp[x][y] = ret;
		return ret;
	}

    public static void main(String[] args) throws Exception {
    	Scanner s = new Scanner(new FileReader("a.in"));
    	int n = s.nextInt();
    	for(int i=0; i<n; i++) {
    		xx = s.nextInt()-1;
    		yy = s.nextInt()-1;
    		dp = new int[25][25];
    		System.out.println(backtrack(0, 0));
    	}
    }
}
