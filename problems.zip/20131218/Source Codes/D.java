import java.util.*;
import java.io.*;

public class D {

    public static void main(String[] args) throws Exception {
    	Scanner s = new Scanner(new FileReader("d.in"));
    	int n = s.nextInt();
    	int[] totient = new int[10000010];
    	for(int i=0; i<10000010; i++)
    		totient[i] = i;
    	for(int i=2; i<10000010; i++)
    		if(totient[i] == i)
    			for(int j=i; j<10000010; j+=i)
    				totient[j] = totient[j]/i*(i-1);
    	for(int i=0; i<n; i++) {
    		int m = s.nextInt();
    		System.out.println(m-totient[m]);
    	}
    }
}
