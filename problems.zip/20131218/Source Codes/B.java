import java.util.*;
import java.io.*;

public class B {
	
	static char[] line;
	static int index;
        
    public static void main(String[] args) throws Exception {
    	Scanner s = new Scanner(new FileReader("b.in"));
    	int n = s.nextInt();
    	for(int i=0; i<n; i++) {
    		line = (s.next()+")").toCharArray();
    		index = 0;
    		System.out.println(evaluate());
    	}
    }
    
    public static int evaluate() {
    	int first = 0, second = 0;
    	char op = ' ';
    	while(index < line.length) {
    		if(line[index] == '(') {
    			index++;
    			int temp = evaluate();
    			if(op == ' ')
    				first = temp;
    			else {
    				second = temp;
    				first = operate(first, second, op);
    			}
    		}
    		else if(line[index] == ')') {
    			index++;
    			return first;
    		}
    		else if(Character.isDigit(line[index])) {
    			if(op == ' ')
    				first = getNumber();
    			else {
    				second = getNumber();
    				first = operate(first, second, op);
    			}
    		}
    		else
    			op = line[index++];
    	}
    	return first;
    }
    
    public static int operate(int first, int second, int op) {
    	switch(op) {
			case '+':
				first = first + second;
				break;
			case '-':
				first = first - second;
				break;
			case '*':
				first = first * second;
				break;
			case '/':
				first = first / second;
				break;
			case '^':
				first = (int) Math.pow(first, second);
				break;
			case '%':
				first = first % second;
				break;
		}
		return first;
    }
    
    public static int getNumber() {
    	int num = 0;
    	while(Character.isDigit(line[index])) {
			num *= 10;
			num += (int)(line[index]-'0');
			index++;
		}
		return num;
    }
}
