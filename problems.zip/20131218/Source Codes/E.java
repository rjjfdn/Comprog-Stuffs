import java.util.*;
import java.io.*;

public class E {
        
    public static void main(String[] args) throws Exception {
    	Scanner s = new Scanner(new FileReader("e.in"));
    	int n = s.nextInt();
    	for(int i=0; i<n; i++) {
    		int[][] matrix = new int[10010][10010];
    		int m = s.nextInt();
    		long count = 0;
    		for(int j=0; j<m; j++) {
    			int x1 = s.nextInt()+5000;
    			int y1 = s.nextInt()+5000;
    			int x2 = s.nextInt()+5000;
    			int y2 = s.nextInt()+5000;
    			for(int k=x1; k<=x2; k++)
    				for(int l=y1; l<=y2; l++) {
    					matrix[k][l]++;
    					if(matrix[k][l] == 1)
    						count++;
    					else if(matrix[k][l] == 2)
    						count--;
    				}
    		}
    		System.out.println(count);
    	}
    }
}
