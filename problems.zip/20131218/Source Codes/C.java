import java.util.*;
import java.io.*;

public class C {

    public static void main(String[] args) throws Exception {
    	Scanner s = new Scanner(new FileReader("c.in"));
    	int n = s.nextInt();
    	for(int i=0; i<n; i++) {
    		double px1 = s.nextDouble();
    		double py1 = s.nextDouble();
    		double px2 = s.nextDouble();
    		double py2 = s.nextDouble();
    		double px3 = s.nextDouble();
    		double py3 = s.nextDouble();
    		double px4 = s.nextDouble();
    		double py4 = s.nextDouble();
    		double qx1 = s.nextDouble();
    		double qy1 = s.nextDouble();
    		double qx2 = s.nextDouble();
    		double qy2 = s.nextDouble();
    		double ans = Math.toDegrees(Math.abs(Math.atan((py1-py2)/(px1-px2)) - Math.atan((py3-py4)/(px3-px4))));
    		if(ans == 0)
    			System.out.println("NONE.");
    		else if(ans < 90)
    			System.out.printf("%.2f\n", ans);
    		else
    			System.out.printf("%.2f\n", 180-ans);
    	}
    }
}
